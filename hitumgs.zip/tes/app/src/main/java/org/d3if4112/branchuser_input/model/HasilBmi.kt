package org.d3if4112.branchuser_input.model

data class HasilBmi(
    val bmi: Float,
    val kategori: KategoriBmi
)



