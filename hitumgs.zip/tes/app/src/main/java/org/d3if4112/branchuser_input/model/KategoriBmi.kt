package org.d3if4112.branchuser_input.model

enum class KategoriBmi {
    KURUS, IDEAL, GEMUK
}
